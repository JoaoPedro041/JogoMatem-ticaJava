class Recorde {
    private String nick;
    private int quantidadeAcertos;

    public Recorde(String nick, int quantidadeAcertos) {
        this.nick = nick;
        this.quantidadeAcertos = quantidadeAcertos;
    }

    public String getNick() {
        return nick;
    }

    public int getQuantidadeAcertos() {
        return quantidadeAcertos;
    }

    public void setQuantidadeAcertos(int quantidadeAcertos2) {
    }
}
